/**
 * 📚 SISTEMA DE GESTÃO DE CONHECIMENTO - Link Mágico
 * Permite adicionar múltiplas fontes de conhecimento além de URLs
 * 
 * SAFE PATCH - BUG-FAQ-003: Migrado para PostgreSQL como armazenamento principal
 * Mantém fallback para filesystem (compatibilidade com desenvolvimento local)
 * 
 * Fontes suportadas:
 * - URLs (web scraping)
 * - PDFs (upload)
 * - FAQs (CSV/JSON)
 * - Texto manual
 * - Documentos (TXT, MD)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class KnowledgeBaseManager {
    constructor() {
        this.knowledgeBases = new Map();
        this.dataPath = path.join(__dirname, 'data', 'knowledge');
        this.db = null;
        this.usePostgres = false;

        this.ensureDataDirectory();

        // Tentar conectar ao PostgreSQL (lazy — será configurado pelo server.js)
        try {
            const { db, USE_POSTGRES } = require('./database');
            if (USE_POSTGRES && db) {
                this.db = db;
                this.usePostgres = true;
                console.log('📚 Knowledge Base: PostgreSQL conectado ✅');
            }
        } catch (err) {
            console.warn('📚 Knowledge Base: PostgreSQL não disponível, usando filesystem (fallback)');
        }

        // Carregar do filesystem como cache inicial (fallback)
        this.loadKnowledgeBases();

        console.log('📚 Sistema de Gestão de Conhecimento inicializado');
    }

    /**
     * Garantir que o diretório existe
     */
    ensureDataDirectory() {
        try {
            if (!fs.existsSync(this.dataPath)) {
                fs.mkdirSync(this.dataPath, { recursive: true });
            }
        } catch (err) {
            console.warn('📚 [Knowledge] Não foi possível criar diretório de dados:', err.message);
        }
    }

    /**
     * Carregar bases de conhecimento salvas (filesystem — fallback/cache)
     */
    loadKnowledgeBases() {
        try {
            if (!fs.existsSync(this.dataPath)) return;
            const files = fs.readdirSync(this.dataPath);

            for (const file of files) {
                if (file.endsWith('.json')) {
                    const filepath = path.join(this.dataPath, file);
                    const data = JSON.parse(fs.readFileSync(filepath, 'utf8'));
                    const chatbotId = file.replace('.json', '');
                    this.knowledgeBases.set(chatbotId, data);
                }
            }

            console.log(`📥 ${this.knowledgeBases.size} base(s) de conhecimento carregadas (filesystem)`);
        } catch (error) {
            console.error('❌ Erro ao carregar bases de conhecimento:', error);
        }
    }

    /**
     * === POSTGRESQL: Salvar KB no banco ===
     */
    async saveToPostgres(chatbotId) {
        if (!this.usePostgres || !this.db) return false;

        try {
            const kb = this.knowledgeBases.get(chatbotId);
            if (!kb) return false;

            const dataJson = JSON.stringify(kb);

            // UPSERT: INSERT ou UPDATE se já existe
            await this.db.query(
                `INSERT INTO tenant_knowledge (api_key, data, updated_at) 
                 VALUES ($1, $2, CURRENT_TIMESTAMP)
                 ON CONFLICT (api_key) 
                 DO UPDATE SET data = $2, updated_at = CURRENT_TIMESTAMP`,
                [chatbotId, dataJson]
            );

            console.log(`💾 [PostgreSQL] KB salva: ${chatbotId.substring(0, 8)}...`);
            return true;
        } catch (error) {
            console.error(`❌ [PostgreSQL] Erro ao salvar KB ${chatbotId.substring(0, 8)}:`, error.message);
            return false;
        }
    }

    /**
     * === POSTGRESQL: Carregar KB do banco ===
     */
    async loadFromPostgres(chatbotId) {
        if (!this.usePostgres || !this.db) return null;

        try {
            const result = await this.db.query(
                'SELECT data FROM tenant_knowledge WHERE api_key = $1',
                [chatbotId]
            );

            if (result.rows && result.rows.length > 0) {
                const data = typeof result.rows[0].data === 'string' 
                    ? JSON.parse(result.rows[0].data) 
                    : result.rows[0].data;
                
                // Atualizar cache em memória
                this.knowledgeBases.set(chatbotId, data);
                console.log(`📥 [PostgreSQL] KB carregada: ${chatbotId.substring(0, 8)}...`);
                return data;
            }
            return null;
        } catch (error) {
            console.error(`❌ [PostgreSQL] Erro ao carregar KB ${chatbotId.substring(0, 8)}:`, error.message);
            return null;
        }
    }

    /**
     * Recarregar base de conhecimento (PostgreSQL → filesystem → memória)
     */
    reloadKnowledgeBase(chatbotId) {
        // Prioridade 1: Tentar PostgreSQL (síncrono via cache — async no background)
        // Para manter compatibilidade com código síncrono existente, 
        // fazemos o load async em background e retornamos o cache
        if (this.usePostgres) {
            // Disparar reload async (atualiza cache para próxima chamada)
            this.loadFromPostgres(chatbotId).catch(err => {
                console.warn('📚 [Knowledge] Reload async falhou:', err.message);
            });
        }

        // Prioridade 2: Cache em memória (já carregado do PostgreSQL ou filesystem)
        if (this.knowledgeBases.has(chatbotId)) {
            return this.knowledgeBases.get(chatbotId);
        }

        // Prioridade 3: Filesystem (fallback)
        try {
            const filepath = path.join(this.dataPath, `${chatbotId}.json`);
            if (fs.existsSync(filepath)) {
                const data = JSON.parse(fs.readFileSync(filepath, 'utf8'));
                this.knowledgeBases.set(chatbotId, data);
                return data;
            }
        } catch (error) {
            console.error(`❌ Erro ao recarregar base de conhecimento ${chatbotId}:`, error);
        }

        return null;
    }

    /**
     * Salvar base de conhecimento (PostgreSQL + filesystem dual-write)
     */
    saveKnowledgeBase(chatbotId) {
        const kb = this.knowledgeBases.get(chatbotId);
        if (!kb) return;

        // Salvar no PostgreSQL (async, não bloqueia)
        if (this.usePostgres) {
            this.saveToPostgres(chatbotId).catch(err => {
                console.warn('📚 [Knowledge] Save PostgreSQL falhou, filesystem ok:', err.message);
            });
        }

        // Salvar no filesystem (fallback síncrono — garantia extra)
        try {
            const filepath = path.join(this.dataPath, `${chatbotId}.json`);
            fs.writeFileSync(filepath, JSON.stringify(kb, null, 2));
        } catch (error) {
            // Não é crítico se filesystem falhar (PostgreSQL é o principal)
            console.warn('📚 [Knowledge] Save filesystem falhou:', error.message);
        }
    }

    /**
     * Inicializar base de conhecimento para um chatbot
     */
    initializeKnowledgeBase(chatbotId, initialData = {}) {
        if (!this.knowledgeBases.has(chatbotId)) {
            // SAFE PATCH - BUG-FAQ-002: Adicionar FAQs de exemplo na inicialização
            const exampleFaqs = [
                {
                    id: 'example_1',
                    question: 'Qual o horário de funcionamento?',
                    answer: 'Funcionamos de segunda a sexta, das 9h às 18h. Aos sábados, das 9h às 13h.',
                    category: 'geral',
                    addedAt: new Date().toISOString(),
                    active: true,
                    hits: 0,
                    isExample: true
                },
                {
                    id: 'example_2',
                    question: 'Quais as formas de pagamento aceitas?',
                    answer: 'Aceitamos PIX, cartão de crédito (até 12x), cartão de débito e boleto bancário.',
                    category: 'pagamento',
                    addedAt: new Date().toISOString(),
                    active: true,
                    hits: 0,
                    isExample: true
                },
                {
                    id: 'example_3',
                    question: 'Tem garantia ou política de reembolso?',
                    answer: 'Sim! Oferecemos garantia incondicional de 7 dias. Se não ficar satisfeito, devolvemos 100% do valor.',
                    category: 'garantia',
                    addedAt: new Date().toISOString(),
                    active: true,
                    hits: 0,
                    isExample: true
                }
            ];

            this.knowledgeBases.set(chatbotId, {
                chatbotId,
                sources: [],
                faqs: exampleFaqs,
                documents: [],
                manualEntries: [],
                lastUpdated: new Date().toISOString(),
                totalEntries: 3
            });

            console.log(`📚 [Knowledge] KB inicializada com 3 FAQs de exemplo para: ${chatbotId.substring(0, 8)}...`);
        }

        // Adicionar dados iniciais se fornecidos
        if (initialData.url) {
            this.addUrlSource(chatbotId, initialData.url, initialData.extractedData);
        }

        this.saveKnowledgeBase(chatbotId);
        return this.knowledgeBases.get(chatbotId);
    }

    /**
     * Adicionar fonte de URL
     */
    addUrlSource(chatbotId, url, extractedData) {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) {
            this.initializeKnowledgeBase(chatbotId);
            return this.addUrlSource(chatbotId, url, extractedData);
        }

        const sourceId = crypto.randomBytes(8).toString('hex');

        const source = {
            id: sourceId,
            type: 'url',
            url,
            data: extractedData,
            addedAt: new Date().toISOString(),
            lastUpdated: new Date().toISOString(),
            active: true
        };

        kb.sources.push(source);
        kb.totalEntries++;
        kb.lastUpdated = new Date().toISOString();

        this.saveKnowledgeBase(chatbotId);

        console.log(`✅ URL adicionada à base de conhecimento: ${url}`);

        return source;
    }

    /**
     * Adicionar FAQ
     */
    addFAQ(chatbotId, question, answer, category = 'geral') {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) {
            this.initializeKnowledgeBase(chatbotId);
            return this.addFAQ(chatbotId, question, answer, category);
        }

        const faqId = crypto.randomBytes(8).toString('hex');

        const faq = {
            id: faqId,
            question,
            answer,
            category,
            addedAt: new Date().toISOString(),
            active: true,
            hits: 0
        };

        kb.faqs.push(faq);
        kb.totalEntries++;
        kb.lastUpdated = new Date().toISOString();

        this.saveKnowledgeBase(chatbotId);

        console.log(`✅ FAQ adicionada: ${question.substring(0, 50)}...`);

        return faq;
    }

    /**
     * Adicionar múltiplas FAQs de uma vez
     */
    addMultipleFAQs(chatbotId, faqs) {
        const addedFaqs = [];

        for (const faq of faqs) {
            const added = this.addFAQ(
                chatbotId,
                faq.question,
                faq.answer,
                faq.category || 'geral'
            );
            addedFaqs.push(added);
        }

        console.log(`✅ ${addedFaqs.length} FAQs adicionadas`);

        return addedFaqs;
    }

    /**
     * Adicionar documento de texto
     */
    addDocument(chatbotId, title, content, metadata = {}) {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) {
            this.initializeKnowledgeBase(chatbotId);
            return this.addDocument(chatbotId, title, content, metadata);
        }

        const docId = crypto.randomBytes(8).toString('hex');

        const document = {
            id: docId,
            type: metadata.type || 'text',
            title,
            content,
            metadata,
            addedAt: new Date().toISOString(),
            active: true
        };

        kb.documents.push(document);
        kb.totalEntries++;
        kb.lastUpdated = new Date().toISOString();

        this.saveKnowledgeBase(chatbotId);

        console.log(`✅ Documento adicionado: ${title}`);

        return document;
    }

    /**
     * Adicionar entrada manual
     */
    addManualEntry(chatbotId, title, content, tags = []) {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) {
            this.initializeKnowledgeBase(chatbotId);
            return this.addManualEntry(chatbotId, title, content, tags);
        }

        const entryId = crypto.randomBytes(8).toString('hex');

        const entry = {
            id: entryId,
            title,
            content,
            tags,
            addedAt: new Date().toISOString(),
            active: true
        };

        kb.manualEntries.push(entry);
        kb.totalEntries++;
        kb.lastUpdated = new Date().toISOString();

        this.saveKnowledgeBase(chatbotId);

        console.log(`✅ Entrada manual adicionada: ${title}`);

        return entry;
    }

    /**
     * Processar arquivo CSV de FAQs
     */
    parseFAQsFromCSV(csvContent) {
        const lines = csvContent.split('\n');
        const faqs = [];

        // Pular cabeçalho
        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();

            if (!line) continue;

            // Parse CSV simples (assumindo formato: pergunta,resposta,categoria)
            const parts = line.split(',');

            if (parts.length >= 2) {
                faqs.push({
                    question: parts[0].trim().replace(/^"|"$/g, ''),
                    answer: parts[1].trim().replace(/^"|"$/g, ''),
                    category: parts[2] ? parts[2].trim().replace(/^"|"$/g, '') : 'geral'
                });
            }
        }

        return faqs;
    }

    /**
     * Processar arquivo JSON de FAQs
     */
    parseFAQsFromJSON(jsonContent) {
        try {
            const data = JSON.parse(jsonContent);

            if (Array.isArray(data)) {
                return data;
            } else if (data.faqs && Array.isArray(data.faqs)) {
                return data.faqs;
            }

            return [];
        } catch (error) {
            console.error('❌ Erro ao parsear JSON:', error);
            return [];
        }
    }

    /**
     * Buscar na base de conhecimento
     */
    search(chatbotId, query, limit = 5) {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) {
            return [];
        }

        const results = [];
        const queryLower = query.toLowerCase();

        // Buscar em FAQs
        for (const faq of kb.faqs) {
            if (!faq.active) continue;

            const questionLower = faq.question.toLowerCase();
            const answerLower = faq.answer.toLowerCase();

            if (questionLower.includes(queryLower) || answerLower.includes(queryLower)) {
                results.push({
                    type: 'faq',
                    score: this.calculateRelevanceScore(queryLower, questionLower),
                    data: faq
                });
            }
        }

        // Buscar em documentos
        for (const doc of kb.documents) {
            if (!doc.active) continue;

            const titleLower = doc.title.toLowerCase();
            const contentLower = doc.content.toLowerCase();

            if (titleLower.includes(queryLower) || contentLower.includes(queryLower)) {
                results.push({
                    type: 'document',
                    score: this.calculateRelevanceScore(queryLower, titleLower + ' ' + contentLower),
                    data: doc
                });
            }
        }

        // Buscar em entradas manuais
        for (const entry of kb.manualEntries) {
            if (!entry.active) continue;

            const titleLower = entry.title.toLowerCase();
            const contentLower = entry.content.toLowerCase();

            if (titleLower.includes(queryLower) || contentLower.includes(queryLower)) {
                results.push({
                    type: 'manual',
                    score: this.calculateRelevanceScore(queryLower, titleLower + ' ' + contentLower),
                    data: entry
                });
            }
        }

        // Ordenar por relevância e limitar resultados
        results.sort((a, b) => b.score - a.score);

        return results.slice(0, limit);
    }

    /**
     * 🔍 SAFE PATCH - KB-SMART-001: Busca inteligente por tokenização de palavras
     * Resolve o problema do search() original que usava .includes() com a frase inteira
     * e falhava com frases naturais como "o que é o link mágico?"
     * 
     * Algoritmo:
     * 1. Normaliza e tokeniza a mensagem do usuário em palavras individuais
     * 2. Normaliza e tokeniza as palavras-chave de cada FAQ
     * 3. Conta matches de palavras individuais
     * 4. Calcula score ponderado (match exato = 2pts, parcial = 1pt)
     * 5. Retorna resultados ordenados por score
     * 
     * @param {string} chatbotId
     * @param {string} query - Mensagem do usuário
     * @param {number} limit - Máximo de resultados
     * @returns {Array} Resultados com { type, score, data }
     */
    searchSmart(chatbotId, query, limit = 3) {
        try {
            const kb = this.knowledgeBases.get(chatbotId);
            if (!kb) return [];

            const results = [];

            // Normalizar: remover acentos, pontuação, lowercase
            const normalize = (str) => {
                return String(str || '')
                    .toLowerCase()
                    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // remover acentos
                    .replace(/[^a-z0-9\s]/g, ' ') // remover pontuação
                    .replace(/\s+/g, ' ')
                    .trim();
            };

            // Tokenizar: separar em palavras, filtrar muito curtas
            const tokenize = (str) => {
                return normalize(str).split(' ').filter(w => w.length >= 2);
            };

            // Stop words em português (não contribuem para o match)
            const stopWords = new Set([
                'de', 'do', 'da', 'dos', 'das', 'em', 'no', 'na', 'nos', 'nas',
                'um', 'uma', 'uns', 'umas', 'ou', 'se', 'ao', 'os', 'as',
                'por', 'para', 'com', 'que', 'me', 'te', 'eu', 'ele', 'ela',
                'voce', 'isso', 'esse', 'essa', 'ola', 'oi', 'bom', 'boa'
            ]);

            const queryTokens = tokenize(query).filter(w => !stopWords.has(w));

            if (queryTokens.length === 0) return [];

            // Buscar em FAQs
            for (const faq of kb.faqs) {
                if (!faq.active) continue;

                const questionTokens = tokenize(faq.question);
                const answerTokens = tokenize(faq.answer);

                let score = 0;
                let matchedWords = 0;

                for (const qToken of queryTokens) {
                    // Match exato na pergunta da FAQ = 3 pontos
                    if (questionTokens.includes(qToken)) {
                        score += 3;
                        matchedWords++;
                    }
                    // Match parcial na pergunta (token contém ou está contido) = 1.5 pontos
                    else if (questionTokens.some(qt => qt.includes(qToken) || qToken.includes(qt))) {
                        score += 1.5;
                        matchedWords++;
                    }
                    // Match na resposta = 0.5 pontos (menor peso)
                    else if (answerTokens.includes(qToken)) {
                        score += 0.5;
                    }
                }

                // Bonus: proporção de palavras do query que deram match
                const matchRatio = matchedWords / queryTokens.length;
                score = score * (0.5 + matchRatio * 0.5);

                // Bonus de especificidade: se uma palavra específica (>= 5 chars) deu match,
                // garante score mínimo de 3 (evita sub-pontuar "pagamento", "checkout", "whatsapp")
                if (matchedWords > 0 && score < 3) {
                    const hasSpecificMatch = queryTokens.some(qt => 
                        qt.length >= 5 && questionTokens.includes(qt)
                    );
                    if (hasSpecificMatch) {
                        score = Math.max(score, 3);
                    }
                }

                // Bonus de bigram: se 2+ palavras adjacentes do query AMBAS estão na FAQ,
                // isso indica intenção forte (ex: "link compra" → FAQ de checkout)
                for (let bi = 0; bi < queryTokens.length - 1; bi++) {
                    const w1InQ = questionTokens.includes(queryTokens[bi]) || 
                                  questionTokens.some(qt => qt.includes(queryTokens[bi]) || queryTokens[bi].includes(qt));
                    const w2InQ = questionTokens.includes(queryTokens[bi + 1]) || 
                                  questionTokens.some(qt => qt.includes(queryTokens[bi + 1]) || queryTokens[bi + 1].includes(qt));
                    if (w1InQ && w2InQ) {
                        score += 2;
                    }
                }

                if (score > 0) {
                    results.push({
                        type: 'faq',
                        score: Math.round(score * 100) / 100,
                        data: faq
                    });
                }
            }

            // Buscar em documentos
            for (const doc of kb.documents) {
                if (!doc.active) continue;

                const titleTokens = tokenize(doc.title);
                const contentTokens = tokenize(doc.content);

                let score = 0;
                for (const qToken of queryTokens) {
                    if (titleTokens.includes(qToken)) score += 2;
                    else if (contentTokens.includes(qToken)) score += 0.5;
                }

                if (score > 0) {
                    results.push({
                        type: 'document',
                        score: Math.round(score * 100) / 100,
                        data: doc
                    });
                }
            }

            // Buscar em entradas manuais
            for (const entry of kb.manualEntries) {
                if (!entry.active) continue;

                const titleTokens = tokenize(entry.title);
                const contentTokens = tokenize(entry.content);

                let score = 0;
                for (const qToken of queryTokens) {
                    if (titleTokens.includes(qToken)) score += 2;
                    else if (contentTokens.includes(qToken)) score += 0.5;
                }

                if (score > 0) {
                    results.push({
                        type: 'manual',
                        score: Math.round(score * 100) / 100,
                        data: entry
                    });
                }
            }

            // Ordenar por score decrescente
            results.sort((a, b) => b.score - a.score);

            console.log(`🔍 [KB-SMART] Query: "${query.substring(0, 50)}" → ${results.length} resultado(s), melhor score: ${results[0]?.score || 0}`);

            return results.slice(0, limit);

        } catch (err) {
            console.warn('⚠️ [KB-SMART] Erro na busca inteligente (fallback vazio):', err.message);
            return [];
        }
    }

    /**
     * Calcular score de relevância (simplificado)
     */
    calculateRelevanceScore(query, text) {
        const queryWords = query.split(/\s+/);
        let score = 0;

        for (const word of queryWords) {
            if (word.length < 3) continue;

            const regex = new RegExp(word, 'gi');
            const matches = text.match(regex);

            if (matches) {
                score += matches.length;
            }
        }

        return score;
    }

    /**
     * Obter toda a base de conhecimento
     */
    getKnowledgeBase(chatbotId) {
        return this.reloadKnowledgeBase(chatbotId) || null;
    }

    /**
     * Compilar contexto para o chatbot
     */
    compileContext(chatbotId, maxLength = 4000) {
        // Recarregar para garantir que pegamos as FAQs mais recentes
        const kb = this.reloadKnowledgeBase(chatbotId);

        if (!kb) {
            return '';
        }

        let context = '';

        // Adicionar FAQs
        if (kb.faqs.length > 0) {
            context += '📋 PERGUNTAS FREQUENTES:\n\n';

            for (const faq of kb.faqs.filter(f => f.active)) {
                const entry = `P: ${faq.question}\nR: ${faq.answer}\n\n`;

                if (context.length + entry.length > maxLength) break;

                context += entry;
            }
        }

        // Adicionar documentos
        if (kb.documents.length > 0 && context.length < maxLength) {
            context += '\n📄 DOCUMENTOS:\n\n';

            for (const doc of kb.documents.filter(d => d.active)) {
                const entry = `${doc.title}:\n${doc.content}\n\n`;

                if (context.length + entry.length > maxLength) break;

                context += entry;
            }
        }

        // Adicionar entradas manuais
        if (kb.manualEntries.length > 0 && context.length < maxLength) {
            context += '\n📝 INFORMAÇÕES ADICIONAIS:\n\n';

            for (const entry of kb.manualEntries.filter(e => e.active)) {
                const entryText = `${entry.title}:\n${entry.content}\n\n`;

                if (context.length + entryText.length > maxLength) break;

                context += entryText;
            }
        }

        // Adicionar dados de URLs
        if (kb.sources.length > 0 && context.length < maxLength) {
            context += '\n🌐 INFORMAÇÕES DO SITE:\n\n';

            for (const source of kb.sources.filter(s => s.active && s.type === 'url')) {
                if (source.data && source.data.textos) {
                    const textos = source.data.textos.slice(0, 10).join('\n');

                    if (context.length + textos.length > maxLength) break;

                    context += textos + '\n\n';
                }
            }
        }

        return context.substring(0, maxLength);
    }

    /**
     * Remover entrada
     */
    removeEntry(chatbotId, entryId, entryType) {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) return false;

        let removed = false;

        switch (entryType) {
            case 'faq':
                const faqIndex = kb.faqs.findIndex(f => f.id === entryId);
                if (faqIndex !== -1) {
                    kb.faqs.splice(faqIndex, 1);
                    removed = true;
                }
                break;

            case 'document':
                const docIndex = kb.documents.findIndex(d => d.id === entryId);
                if (docIndex !== -1) {
                    kb.documents.splice(docIndex, 1);
                    removed = true;
                }
                break;

            case 'manual':
                const entryIndex = kb.manualEntries.findIndex(e => e.id === entryId);
                if (entryIndex !== -1) {
                    kb.manualEntries.splice(entryIndex, 1);
                    removed = true;
                }
                break;

            case 'source':
                const sourceIndex = kb.sources.findIndex(s => s.id === entryId);
                if (sourceIndex !== -1) {
                    kb.sources.splice(sourceIndex, 1);
                    removed = true;
                }
                break;
        }

        if (removed) {
            kb.totalEntries--;
            kb.lastUpdated = new Date().toISOString();
            this.saveKnowledgeBase(chatbotId);
            console.log(`🗑️ Entrada removida: ${entryId}`);
        }

        return removed;
    }

    /**
     * Obter estatísticas
     */
    getStats(chatbotId) {
        const kb = this.knowledgeBases.get(chatbotId);

        if (!kb) {
            return {
                totalEntries: 0,
                sources: 0,
                faqs: 0,
                documents: 0,
                manualEntries: 0
            };
        }

        return {
            totalEntries: kb.totalEntries,
            sources: kb.sources.filter(s => s.active).length,
            faqs: kb.faqs.filter(f => f.active).length,
            documents: kb.documents.filter(d => d.active).length,
            manualEntries: kb.manualEntries.filter(e => e.active).length,
            lastUpdated: kb.lastUpdated
        };
    }
}

// Instância global do gerenciador de conhecimento
const knowledgeBaseManager = new KnowledgeBaseManager();

module.exports = {
    knowledgeBaseManager
};
